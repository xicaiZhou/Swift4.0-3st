//
//  ViewController.swift
//  第一章基础语法简介第三讲
//
//  Created by 周希财 on 2017/9/21.
//  Copyright © 2017年 VIC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //第一节 Swift中的标识符
        
        //标识符定义:所谓标识符是编程语言中用于指代一个对象或一个类型的名字。
        //Swift中标识符的命名规范:
                             //1.标识符中不能含有空白符（包括换行符，空格，制表符等）、数字符号、箭头、私有使用（或无效的）Unicode码点以及画线、画边框有关的符号（除了下划线）。
                             //2.不允许使用数字开头。
                             //3.在ASCII中，除了下划线与$,其他非数字，非字母符号都不能用于标识符。
                             //4.标识符不能使用$开头,但单一的$可以作为标识符。
        
        //下面我们看看一些合法的标识符
        
        let _0 = 0 ; let a$b = 0; let $ = 0
        
        let _$ = 0; let 你 = 0; let ０１２３ = 0  //这里日语中全角数组可以作为有效的标识符
        
        let 🍌 = 0                          //Emoji表情也可以作为有效的标识符
        
        
        //下面我们看看一些不合法的标识符
        
        let a b = 0                                      //标识符中含有空白符
        let 0a = 0                                       //标识符中以数字开头
        let $0 = 0; let $a = 0; let $$ = 0               //标识符中以$开头
        let □◆×○↑∫÷∞ = 0                                 //这种字符在标识符中都是不合法的
        
        
        //此外，Swift语言允许在某些场合使用自己的关键字来作为标识符，比如作为函数的参数标签。我们在牵涉到关键字的时候需要谨慎使用
        
        func foo(in : Int, for : inout Int){
        
            //这里是用关键字in for 作为参数标签名
            //但是不能使用inout作为参数标签名
        }
        
        //在Swift中可以通过对关键字前后加`符号作为标识符来使用。
        
        let `var` = 0
        let `let` = 0
        let `inout` = 0
        let `hello` = 0  //`除了关键字外，还能拍房子啊其他的合法标识符中，但是不允许放在非法标识符中。
        
        
        
        
        
        //第二节 Swift中的注释
        //Swift中的注释和C语言的注释完全一样，可以使用一下段落注释的形式：
        
        /**
         *   这是一个注释段
         */
        
        
        //也可以使用行注释的形式
        
        //这是一个注释行
        
        //在Xcode中，Swift语言也有类似于OC那种通过注释的方式给函数、类型等文档化的格式。Apple官方称为Markup “https://developer.apple.com/library/content/documentation/Xcode/Reference/xcode_markup_formatting_ref/index.html#//apple_ref/doc/uid/TP40016497”，这里简单的介绍一下Markup的一些基本用法。
        
        
         
        //eg
        /**
         这是一个注释语句。
         这又是一条注释语句。
         */
        
        //下面这个是OC用doxygen格式化文档
        

        /**
         * 这是一个注释语句。
         * 这又是一条注释语句。
         */
        func fooo(){
        
        }
        
        //在使用行注释做Markup格式化文档的时候必须使用三条斜杠，必须。
        //eg
        ///这是markup格式下的行注释
        
        
        //Markup中具有许多参数可生成高亮格式的文字,以下参数比较常用
        //1.attention:表示需要代码阅读者注意的地方
        //2.important:表示这里的描述十分重要
        //3.note:表示标注，一般用于记载不怎么重要的事物，作为补充说明
        //4.warning:表示十分紧要的内容，这部分可以说明如果某些接口无用会呆滞程序崩溃等非常致命的错误
        //5.version:表示当前类型或函数的版本号
        
        //注意事项：在使用参数时，必须要在参数前面加一个-号，然后在参数后面加冒号，再跟描述文字。
        
        //eg
        /// -improtant: 这里很重要
        
        
        
        //此外，像Objective-C中用于代码分段的 #pragma mark - 在Swift中是通过注释方式来实现的。因为Swift中没有 #pragma 预处理器指示符，所以使用 // MARK: 来表示标记分段。
        
        // MARK:test函数
        func test(){
        
        }
        
        //除了 // MARK: 之外，还有 // TODO: 以及 // FIXME:。
        
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

